import { useSidebar } from "@/shared/hooks/use-sidebar";
import { useTheme } from "@/shared/hooks/use-theme";
//import AppHeader from "@/shared/ui/header/AppHeader";
//import AppSidebar from "@/shared/ui/sidebar/AppSidebar";
import { createContext, useContext } from "react";
import { Outlet } from "react-router-dom";
import { MainSidebar } from "../partials/MainSidebar";
import { cn } from "@/shared/lib/cn";
import { SidebarPanel } from "../partials/SidebarPanel";
import { TopHeader } from "../partials/TopHeader";

interface SidebarContextValue {
  isOpen: boolean;
  toggle: () => void;
  close: () => void;
}

const SidebarContext = createContext<SidebarContextValue | null>(null);

export const useSidebarContext = () => {
  const ctx = useContext(SidebarContext);
  if (!ctx) throw new Error("useSidebarContext must be inside DashboardLayout");
  return ctx;
};

function DashboardLayout() {
  const { isDark, toggleTheme } = useTheme();
  const { isOpen, toggle, close } = useSidebar();
  return (
    <SidebarContext.Provider value={{ isOpen, toggle, close }}>
      <MainSidebar isOpen={isOpen} onNavClick={toggle} />

      <div
        className={cn(
          "flex flex-1 flex-col transition-all duration-[250ms]",
          // Offset content to the right of the icon rail on md+
          "md:ml-[var(--main-sidebar-width)]",
          // On xl, further offset when sidebar panel is open
          isOpen &&
            "xl:ml-[calc(var(--main-sidebar-width)+var(--sidebar-panel-width))]",
        )}
      >
        {/* ── Sidebar panel (slides in/out) ──────────────────── */}
        <SidebarPanel isOpen={isOpen} onClose={close} />
        {/* Top header */}
        <TopHeader
            isSidebarOpen={isOpen}
            onToggleSidebar={toggle}
            isDark={isDark}
            onToggleTheme={toggleTheme}
          />

        <main
          className={cn(
            "mt-[var(--header-height)] flex-1 p-[var(--margin-x)]",
            "transition-[padding] duration-[250ms]",
          )}
        >
          <Outlet />
        </main>
      </div>
    </SidebarContext.Provider>

    // <div className="min-h-screen flex">
    //   <AppSidebar />
    //   <div className="flex-1">
    //     <AppHeader isDark={isDark} onToggleTheme={toggleTheme} />
    //     <main className="p-6">
    //       <Outlet />
    //     </main>
    //   </div>
    // </div>
  );
}

export default DashboardLayout;
